#include "gestion_rendezvous.h"
#include "ui_gestion_rendezvous.h"
#include <QMessageBox>
#include <QSqlError>
#include <QUuid>
#include <QRegularExpression>
#include <QPrinter>
#include <QPainter>
#include <QSortFilterProxyModel>
#include <QNetworkAccessManager>
#include <QNetworkRequest>
#include <QNetworkReply>
#include <QUrl>
#include <QUrlQuery>
#include <QDate>
#include <QTextCharFormat>


gestion_rendezvous::gestion_rendezvous(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::gestion_rendezvous)
    , proxyModel(new QSortFilterProxyModel(this))
{
    ui->setupUi(this);
    chargerclient();
    afficherRendezVous();
    afficherCalendrierRendezVous();


    connect(ui->ajouterButton, &QPushButton::clicked, this, &gestion_rendezvous::on_ajouterButton_clicked);
    connect(ui->supprimerButton, &QPushButton::clicked, this, &gestion_rendezvous::on_supprimerButton_clicked);
    connect(ui->pushButton_modifier, &QPushButton::clicked, this, &gestion_rendezvous::on_modifierButton_clicked);
    connect(ui->pdf, &QPushButton::clicked, this, &gestion_rendezvous::on_exportPdfButton_clicked);
    connect(ui->chercher, &QLineEdit::textChanged, this, &gestion_rendezvous::chercherRendezVous);
    connect(ui->trier, &QPushButton::clicked, this, &gestion_rendezvous::on_filtrer_clicked);
    connect(ui->bsms, &QPushButton::clicked, this, &gestion_rendezvous::on_bsms_clicked);

    connect(ui->pushButton_charger, &QPushButton::clicked, this, [this]() {
        QString id = ui->IDRDV->text().trimmed();
        if (!id.isEmpty()) {
            chargerRendezVousParID(id);
        } else {
            QMessageBox::warning(this, "Champ vide", "Veuillez entrer un ID RDV.");
        }
    });  // ✅ Parenthèse FERMANTE manquante ici !
}

gestion_rendezvous::~gestion_rendezvous()
{
    delete ui;
}

void gestion_rendezvous::chargerclient()
{
    QSqlQuery query;

    if (!query.exec("SELECT NOM_CLIENT FROM CLIENT")) {
        QMessageBox::critical(this, "Erreur SQL", "Impossible de charger les clients : " + query.lastError().text());
        return;
    }

    ui->client->clear();
    ui->client->addItem("Sélectionnez un client");

    while (query.next()) {
        QString nomClient = query.value(0).toString();
        ui->client->addItem(nomClient);
    }
}


void gestion_rendezvous::afficherRendezVous()
{
    QSqlQueryModel *model = new QSqlQueryModel();

    model->setQuery("SELECT ID_RDV, DATE_RDV, HEURE_RDV, STATUS_RDV, EMAIL, DOMAINE FROM RENDEZ_VOUS");

    if (model->lastError().isValid()) {
        QMessageBox::critical(this, "Erreur SQL", "Échec de l'affichage : " + model->lastError().text());
        delete model;
        return;
    }

    model->setHeaderData(0, Qt::Horizontal, "ID");
    model->setHeaderData(1, Qt::Horizontal, "Date");
    model->setHeaderData(2, Qt::Horizontal, "Heure");
    model->setHeaderData(3, Qt::Horizontal, "Statut");
    model->setHeaderData(4, Qt::Horizontal, "Email");
    model->setHeaderData(5, Qt::Horizontal, "Domaine");

    ui->tableView->setModel(model);
    ui->tableView->resizeColumnsToContents();
}


void gestion_rendezvous::on_ajouterButton_clicked()
{
    QString id_rdv = QUuid::createUuid().toString(QUuid::WithoutBraces);
    QDate date_rdv = ui->daterdv->date();
    QTime heure_rdv = ui->heure->time();
    QString status_rdv = ui->statut->currentText();
    QString email = ui->mail->text().trimmed();
    QString domaine = ui->domaine->currentText();

    if (email.isEmpty() || domaine.isEmpty() || status_rdv.isEmpty()) {
        QMessageBox::warning(this, "Erreur", "Veuillez remplir tous les champs obligatoires.");
        return;
    }

    QRegularExpression regexEmail("^[\\w.-]+@[\\w.-]+\\.[a-zA-Z]{2,}$");
    if (!regexEmail.match(email).hasMatch()) {
        QMessageBox::warning(this, "Erreur", "Veuillez entrer une adresse email valide.");
        return;
    }

    RendezVous rdv(id_rdv, date_rdv, heure_rdv, status_rdv, email, domaine);

    if (rdv.ajouter()) {
        QMessageBox::information(this, "Succès", "Le rendez-vous a été ajouté avec succès.");
        afficherRendezVous();
    } else {
        QMessageBox::critical(this, "Erreur", "Échec de l'ajout du rendez-vous.");
    }
    afficherCalendrierRendezVous();
}



void gestion_rendezvous::chargerRendezVousParID(const QString& id)
{
    QSqlQuery query;
    query.prepare("SELECT ID_RDV, DATE_RDV, HEURE_RDV, STATUS_RDV, EMAIL, DOMAINE FROM RENDEZ_VOUS WHERE ID_RDV = :id");
    query.bindValue(":id", id);

    if (!query.exec()) {
        QMessageBox::critical(this, "Erreur", "Erreur SQL : " + query.lastError().text());
        return;
    }

    if (query.next()) {
        ui->lineEdit_id->setText(query.value("ID_RDV").toString());
        ui->daterdv_2->setDate(query.value("DATE_RDV").toDate());
        ui->heure_2->setTime(query.value("HEURE_RDV").toTime());
        ui->statut_2->setCurrentText(query.value("STATUS_RDV").toString());
        ui->mail_2->setText(query.value("EMAIL").toString());
        ui->domaine_2->setCurrentText(query.value("DOMAINE").toString());
    } else {
        QMessageBox::warning(this, "Introuvable", "Aucun rendez-vous trouvé avec l'identifiant fourni.");
    }
}

void gestion_rendezvous::on_modifierButton_clicked()
{
    QString id_rdv = ui->IDRDV->text().trimmed();
    QDate date_rdv = ui->daterdv_2->date();
    QTime heure_rdv = ui->heure_2->time();
    QString status_rdv = ui->statut_2->currentText();
    QString email = ui->mail_2->text().trimmed();
    QString domaine = ui->domaine_2->currentText();

    if (id_rdv.isEmpty() || email.isEmpty() || domaine.isEmpty() || status_rdv.isEmpty()) {
        QMessageBox::warning(this, "Champs manquants", "Veuillez remplir tous les champs obligatoires.");
        return;
    }

    QRegularExpression regexEmail("^[\\w.-]+@[\\w.-]+\\.[a-zA-Z]{2,}$");
    if (!regexEmail.match(email).hasMatch()) {
        QMessageBox::warning(this, "Email invalide", "Veuillez entrer une adresse email valide.");
        return;
    }

    QSqlQuery query;
    query.prepare("UPDATE RENDEZ_VOUS SET DATE_RDV = :date, HEURE_RDV = :heure, STATUS_RDV = :status, EMAIL = :email, DOMAINE = :domaine WHERE ID_RDV = :id");
    query.bindValue(":date", date_rdv);
    query.bindValue(":heure", heure_rdv);
    query.bindValue(":status", status_rdv);
    query.bindValue(":email", email);
    query.bindValue(":domaine", domaine);
    query.bindValue(":id", id_rdv);

    if (query.exec()) {
        QMessageBox::information(this, "Succès", "Le rendez-vous a été modifié avec succès.");
        afficherRendezVous();
    } else {
        QMessageBox::critical(this, "Erreur SQL", "Échec de la modification : " + query.lastError().text());
    }
    afficherCalendrierRendezVous();
}


void gestion_rendezvous::on_supprimerButton_clicked()
{
    QString id_rdv = ui->rdv->text().trimmed(); // Récupère l'ID du rendez-vous depuis le QLineEdit
    if (id_rdv.isEmpty()) {
        QMessageBox::warning(this, "Erreur", "Veuillez entrer un ID de rendez-vous valide.");
        return;
    }

    QSqlQuery query;
    query.prepare("DELETE FROM RENDEZ_VOUS WHERE ID_RDV = :id");
    query.bindValue(":id", id_rdv);

    if (query.exec()) {
        QMessageBox::information(this, "Succès", "Le rendez-vous a été supprimé avec succès.");
        afficherRendezVous(); // Rafraîchit l'affichage des rendez-vous
    } else {
        QMessageBox::critical(this, "Erreur SQL", "Échec de la suppression : " + query.lastError().text());
    }
    afficherCalendrierRendezVous();
}


void gestion_rendezvous::on_exportPdfButton_clicked()
{
    // Créer un objet QPrinter pour générer un fichier PDF
    QPrinter printer(QPrinter::HighResolution);
    printer.setOutputFormat(QPrinter::PdfFormat);   // Définir le format de sortie en PDF
    printer.setOutputFileName("export_rendezvous.pdf"); // Nom du fichier PDF

    // Utilisation correcte de QPageSize pour la taille A4
    printer.setPageSize(QPageSize(QPageSize::A4));  // Taille de la page (A4)

    // Créer un QPainter pour dessiner le contenu de la table dans le PDF
    QPainter painter;
    if (!painter.begin(&printer)) {
        QMessageBox::critical(this, "Erreur", "Impossible de créer le PDF.");
        return;
    }

    // Définir les marges du PDF
    int xOffset = 30;
    int yOffset = 30;
    int tableTop = yOffset + 30;

    // Récupérer le modèle de la table et le nombre de lignes et de colonnes
    QAbstractItemModel *model = ui->tableView->model();
    int rowCount = model->rowCount();
    int columnCount = model->columnCount();

    // Définir la largeur des colonnes et la hauteur des lignes
    int columnWidth = 1000;  // Ajusté pour vos besoins
    int rowHeight = 200;
    int tableWidth = columnWidth * columnCount;

    // Définir la police pour l'ensemble du tableau
    QFont font = painter.font();
    font.setPointSize(12);  // Taille de la police
    painter.setFont(font);

    // Dessiner le titre de chaque colonne (en-têtes)
    painter.setPen(Qt::black);

    // Définir une police spécifique pour les en-têtes
    QFont headerFont("Arial", 10, QFont::Bold);  // Police Arial, taille 10, en gras
    painter.setFont(headerFont);

    QColor headerBackground(220, 220, 220);  // Couleur de fond des en-têtes (gris clair)
    QColor textColor(0, 0, 0);  // Couleur du texte (noir)

    // Dessiner les en-têtes de colonnes
    for (int column = 0; column < columnCount; ++column) {
        QString header = model->headerData(column, Qt::Horizontal).toString();
        QRect headerRect(xOffset + column * columnWidth, tableTop, columnWidth, rowHeight);
        painter.fillRect(headerRect, headerBackground);  // Fond gris clair pour les en-têtes
        painter.setPen(textColor);  // Texte noir
        painter.drawRect(headerRect); // Bordure de la cellule
        painter.drawText(headerRect, Qt::AlignCenter, header); // Centrer le texte dans la cellule
    }

    // Dessiner les lignes du tableau avec des bordures
    painter.setFont(QFont()); // Revenir à la police normale
    QColor rowBackground(255, 255, 255);  // Fond des lignes (blanc)
    for (int row = 0; row < rowCount; ++row) {
        int rowY = tableTop + (row + 1) * rowHeight;
        if (row % 2 == 0) {
            painter.fillRect(xOffset, rowY, tableWidth, rowHeight, rowBackground);  // Fond blanc pour les lignes
        }

        for (int column = 0; column < columnCount; ++column) {
            QString cellText = model->data(model->index(row, column)).toString();

            // Si la colonne est celle de la date, formater la date
            if (column == 1) {  // Supposons que la colonne 1 contient des dates
                QDate date = model->data(model->index(row, column)).toDate();
                if (date.isValid()) {
                    cellText = date.toString("dd MMM yyyy"); // Format : jour mois année
                }
            }

            // Si la colonne est celle de l'heure, formater l'heure
            if (column == 2) {  // Supposons que la colonne 2 contient des heures
                QTime time = model->data(model->index(row, column)).toTime();
                if (time.isValid()) {
                    cellText = time.toString("HH:mm"); // Format de l'heure
                }
            }

            QRect cellRect(xOffset + column * columnWidth, rowY, columnWidth, rowHeight);
            painter.setPen(Qt::black); // Bordure noire autour des cellules
            painter.drawRect(cellRect);  // Dessiner la bordure
            painter.drawText(cellRect, Qt::AlignCenter, cellText);  // Centrer le texte dans la cellule
        }
    }

    // Ajouter une bordure autour du tableau
    painter.setPen(QPen(Qt::black, 2)); // Bordure plus épaisse autour du tableau
    QRect tableRect(xOffset, tableTop, tableWidth, rowHeight * (rowCount + 1));
    painter.drawRect(tableRect);

    // Terminer le dessin dans le PDF
    painter.end();

    QMessageBox::information(this, "Succès", "Le tableau des rendez-vous a été exporté en PDF.");
}

void gestion_rendezvous::chercherRendezVous()
{
    QString ID_RDV = ui->chercher->text().trimmed();  // Récupère l'ID du rendez-vous depuis le champ de texte

    QSqlQuery query;
    QSqlQueryModel* model = new QSqlQueryModel();

    // Si aucun texte, afficher tous les rendez-vous
    if (ID_RDV.isEmpty()) {
        query.prepare("SELECT * FROM RENDEZ_VOUS");
    } else {
        // Rechercher avec un ID partiel (LIKE pour recherche partielle)
        query.prepare("SELECT * FROM RENDEZ_VOUS WHERE ID_RDV LIKE :id");
        query.bindValue(":id", ID_RDV + "%");  // Recherche avec correspondance partielle depuis le début de l'ID
    }

    if (!query.exec()) {
        qDebug() << "Erreur SQL : " << query.lastError().text();
        delete model;
        return;
    }

    model->setQuery(std::move(query));
    ui->tableView->setModel(model);  // Affiche les résultats dans le QTableView
}

void gestion_rendezvous::on_filtrer_clicked()
{
    // Créer un modèle pour la requête SQL sans tri initial
    QSqlQueryModel *sqlModel = new QSqlQueryModel();

    // Définir la requête SQL pour récupérer les rendez-vous sans appliquer de tri
    sqlModel->setQuery("SELECT ID_RDV, DATE_RDV, HEURE_RDV, STATUS_RDV, EMAIL, DOMAINE "
                       "FROM RENDEZ_VOUS");

    // Vérifier si la requête a échoué
    if (sqlModel->lastError().isValid()) {
        QMessageBox::critical(this, "Erreur SQL", sqlModel->lastError().text());
        return;
    }

    // Assurez-vous que le proxyModel est initialisé
    if (!proxyModel) {
        proxyModel = new QSortFilterProxyModel(this);
    }

    // Assigner le modèle source à proxyModel
    proxyModel->setSourceModel(sqlModel);

    // Récupérer l'option de tri choisie (croissant ou décroissant)
    QString ordre = ui->tri->currentText(); // "Croissant" ou "Décroissant"
    Qt::SortOrder sortOrder = Qt::AscendingOrder;  // Valeur par défaut pour le tri croissant

    // Si l'option est "Décroissant", changer l'ordre de tri
    if (ordre == "Decroissant") {
        sortOrder = Qt::DescendingOrder;
    }

    // Appliquer le tri sur la colonne DATE_RDV (index 1)
    proxyModel->sort(1, sortOrder);  // Tri sur la colonne 1 (DATE_RDV)

    // Appliquer le proxyModel à la vue de la table pour l'affichage
    ui->tableView->setModel(proxyModel);
    ui->tableView->resizeColumnsToContents();  // Adapter les colonnes à la taille du contenu
}

void gestion_rendezvous::envoyerSMS(const QString &numero, const QString &message) {
    QNetworkAccessManager *manager = new QNetworkAccessManager();

    QUrl url("https://api.twilio.com/2010-04-01/Accounts/ACead860ac4f7bf791b7a94d21d13d6574/Messages.json");

    QNetworkRequest request(url);
    request.setHeader(QNetworkRequest::ContentTypeHeader, "application/x-www-form-urlencoded");

    QString from = "+17759421417";  // Ton numéro Twilio
    QString to = numero;

    // ✅ Formatage du numéro en international si nécessaire
    if (!to.startsWith("+")) {
        to = "+216" + to;  // Par exemple pour la Tunisie
    }

    QUrlQuery postData;
    postData.addQueryItem("From", from);
    postData.addQueryItem("To", to);
    postData.addQueryItem("Body", message);

    // ✅ Authentification Basic : SID:Token
    QByteArray credentials = "ACead860ac4f7bf791b7a94d21d13d6574:33156592d51c837ce0252a2fa86ea557";
    request.setRawHeader("Authorization", "Basic " + credentials.toBase64());

    // ✅ Réponse
    QObject::connect(manager, &QNetworkAccessManager::finished, [=](QNetworkReply *reply) {
        if (reply->error() == QNetworkReply::NoError) {
            qDebug() << "✅ SMS envoyé avec succès à" << to;
        } else {
            qDebug() << "❌ Erreur d'envoi SMS:" << reply->errorString();
            qDebug() << "➡ Réponse Twilio:" << reply->readAll();
        }
        reply->deleteLater();
        manager->deleteLater();  // Nettoyage
    });

    manager->post(request, postData.toString(QUrl::FullyEncoded).toUtf8());
}

#include "gestion_rendezvous.h"
#include <QSqlQuery>
#include <QSqlRecord>
#include <QDebug>

void gestion_rendezvous::notifierRendezVous()
{
    QSqlQuery query;

    // Récupérer tous les rendez-vous à venir avec les informations client
    QString sql = R"(
        SELECT CLIENT.NUM_TEL, CLIENT.NOM_CLIENT, RENDEZ_VOUS.DATE_RDV, RENDEZ_VOUS.HEURE_RDV
        FROM CLIENT
        JOIN RENDEZ_VOUS ON CLIENT.ID_RDV = RENDEZ_VOUS.ID_RDV
        WHERE RENDEZ_VOUS.DATE_RDV >= CURRENT_DATE
    )";

    if (!query.exec(sql)) {
        qDebug() << "Erreur lors de l'exécution de la requête:" << query.lastError().text();
        return;
    }

    while (query.next()) {
        QString numero = query.value("NUM_TEL").toString();
        QString nom = query.value("NOM_CLIENT").toString();
        QString date = query.value("DATE_RDV").toDate().toString("dd/MM/yyyy");
        QString heure = query.value("HEURE_RDV").toTime().toString("hh:mm");

        QString message = QString("Bonjour %1, votre rendez-vous est prévu pour le %2 à %3.")
                              .arg(nom)
                              .arg(date)
                              .arg(heure);

        envoyerSMS(numero, message);  // Tu dois avoir cette fonction quelque part
    }
}



void gestion_rendezvous::on_bsms_clicked()
{
    gestion_rendezvous::notifierRendezVous();

    QMessageBox::information(this, "SMS envoyés", "Les clients ont été notifiés par SMS.");
}


void gestion_rendezvous::afficherCalendrierRendezVous()
{
    QSqlQuery query;
    QTextCharFormat formatLibre;
    formatLibre.setBackground(Qt::green);

    QTextCharFormat formatOccupe;
    formatOccupe.setBackground(Qt::red);

    // Mettre tous les jours à vert (libres) pour une période donnée
    QDate debut(2025, 1, 1);
    QDate fin(2030, 12, 31);

    for (QDate date = debut; date <= fin; date = date.addDays(1)) {
        ui->calendarWidget->setDateTextFormat(date, formatLibre);
    }

    // Requête adaptée à ta table : STRATEDGE.RENDEZ_VOUS
    if (query.exec("SELECT DATE_RDV FROM RENDEZ_VOUS")) {
        while (query.next()) {
            QDate dateOccupee = query.value(0).toDate();
            ui->calendarWidget->setDateTextFormat(dateOccupee, formatOccupe);
        }
    } else {
        qDebug() << "Erreur lors de la récupération des rendez-vous : " << query.lastError().text();
    }
}
