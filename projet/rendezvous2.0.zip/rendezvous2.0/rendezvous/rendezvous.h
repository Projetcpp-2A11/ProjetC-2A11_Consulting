#ifndef RENDEZVOUS_H
#define RENDEZVOUS_H

#include <QString>
#include <QSqlQuery>
#include <QSqlQueryModel>
#include <QDate>
#include <QTime>

class RendezVous {
private:
    QString id_rdv;
    QDate date_rdv;
    QTime heure_rdv;
    QString status_rdv;
    QString email;
    QString domaine;

public:
    // Constructeurs
    RendezVous();
    RendezVous(const QString& id_rdv, const QDate& date_rdv, const QTime& heure_rdv,
               const QString& status_rdv, const QString& email, const QString& domaine);

    // Getters
    QString getIdRdv() const;
    QDate getDateRdv() const;
    QTime getHeureRdv() const;
    QString getStatusRdv() const;
    QString getEmail() const;
    QString getDomaine() const;

    // Setters
    void setIdRdv(const QString& id_rdv);
    void setDateRdv(const QDate& date_rdv);
    void setHeureRdv(const QTime& heure_rdv);
    void setStatusRdv(const QString& status_rdv);
    void setEmail(const QString& email);
    void setDomaine(const QString& domaine);

    // Méthodes CRUD
    bool ajouter();
    QSqlQueryModel* afficher();
    bool modifier(const QString& id_rdv, const QDate& date_rdv, const QTime& heure_rdv,
                  const QString& status_rdv, const QString& email, const QString& domaine);
    bool supprimer(const QString& id_rdv);
    QSqlQueryModel* trierParDate();
    bool exporterPDF(const QString& filePath);
};

#endif // RENDEZVOUS_H
