#include "rendezvous.h"
#include <QSqlQuery>
#include <QSqlError>
#include <QSqlQueryModel>
#include <QDebug>
#include <QUuid>

RendezVous::RendezVous() {}

RendezVous::RendezVous(const QString& id, const QDate& date, const QTime& heure, const QString& statut, const QString& email, const QString& domaine) {
    id_rdv = id;
    date_rdv = date;
    heure_rdv = heure;
    status_rdv = statut;
    this->email = email;
    this->domaine = domaine;
}

bool RendezVous::ajouter()
{
    QSqlQuery query;
    query.prepare("INSERT INTO RENDEZ_VOUS (ID_RDV, DATE_RDV, HEURE_RDV, STATUS_RDV, EMAIL, DOMAINE) "
                  "VALUES (:ID_RDV, TO_DATE(:DATE_RDV, 'YYYY-MM-DD'), TO_TIMESTAMP(:HEURE_RDV, 'HH24:MI:SS'), :STATUS_RDV, :EMAIL, :DOMAINE)");

    query.bindValue(":ID_RDV", id_rdv);
    query.bindValue(":DATE_RDV", date_rdv.toString("yyyy-MM-dd"));
    query.bindValue(":HEURE_RDV", heure_rdv.toString("HH:mm:ss"));
    query.bindValue(":STATUS_RDV", status_rdv);
    query.bindValue(":EMAIL", email);
    query.bindValue(":DOMAINE", domaine);

    if (!query.exec()) {
        qDebug() << "Erreur lors de l'ajout du rendez-vous:" << query.lastError().text();
        return false;
    }

    qDebug() << "Rendez-vous ajouté avec succès.";
    return true;
}

QSqlQueryModel* RendezVous::afficher()
{
    QSqlQueryModel* model = new QSqlQueryModel();
    QSqlQuery query("SELECT * FROM RENDEZ_VOUS");

    if (!query.exec()) {
        qDebug() << "Erreur lors de l'exécution de la requête : " << query.lastError().text();
        return nullptr;  // Retourner null si la requête échoue
    }

    model->setQuery(query);

    if (model->rowCount() == 0) {
        qDebug() << "Aucun rendez-vous trouvé.";
    }

    return model;
}


bool RendezVous::modifier(const QString& id_rdv, const QDate& date_rdv, const QTime& heure_rdv,
                          const QString& status_rdv, const QString& email, const QString& domaine)
{
    QSqlQuery query;
    query.prepare("UPDATE RENDEZ_VOUS SET DATE_RDV = TO_DATE(:DATE_RDV, 'YYYY-MM-DD'), "
                  "HEURE_RDV = TO_TIMESTAMP(:HEURE_RDV, 'HH24:MI:SS'), STATUS_RDV = :STATUS_RDV, "
                  "EMAIL = :EMAIL, DOMAINE = :DOMAINE WHERE ID_RDV = :ID_RDV");

    query.bindValue(":ID_RDV", id_rdv);
    query.bindValue(":DATE_RDV", date_rdv.toString("yyyy-MM-dd"));
    query.bindValue(":HEURE_RDV", heure_rdv.toString("HH:mm:ss"));
    query.bindValue(":STATUS_RDV", status_rdv);
    query.bindValue(":EMAIL", email);
    query.bindValue(":DOMAINE", domaine);

    if (!query.exec()) {
        qDebug() << "Erreur lors de la modification du rendez-vous:" << query.lastError().text();
        return false;
    }

    qDebug() << "Rendez-vous modifié avec succès.";
    return true;
}

bool RendezVous::supprimer(const QString& ID_RDV) {
    QSqlQuery query;
    query.prepare("DELETE FROM RENDEZ_VOUS WHERE ID_RDV = :ID_RDV");
    query.bindValue(":ID_RDV", ID_RDV);

    if (!query.exec()) {
        qDebug() << "Erreur lors de la suppression du rendez-vous :" << query.lastError().text();
        return false;
    }

    if (query.numRowsAffected() == 0) {
        qDebug() << "Aucun rendez-vous trouvé avec l'ID :" << ID_RDV;
        return false;
    }

    return true;
}


QSqlQueryModel* RendezVous::trierParDate()
{
    QSqlQueryModel* model = new QSqlQueryModel();
    QSqlQuery query("SELECT * FROM RENDEZ_VOUS ORDER BY DATE_RDV ASC");

    if (query.exec()) {
        model->setQuery(query);
    } else {
        qDebug() << "Erreur lors du tri des rendez-vous par date:" << query.lastError().text();
    }

    return model;
}

bool RendezVous::exporterPDF(const QString& filePath)
{
    // Ajouter votre code pour exporter le rendez-vous en PDF ici
    return false;
}
