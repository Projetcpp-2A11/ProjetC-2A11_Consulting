#include "connection.h"

Connection::Connection(){}

bool Connection::createconnection()
{
    db= QSqlDatabase::addDatabase("QODBC");
    bool test=false;
    db.setDatabaseName("stratedgge");
    db.setUserName("stratedgge");
    db.setPassword("consulting");

    if (db.open()) test=true;

    return test;

}
void Connection::closeConnection(){db.close();}
