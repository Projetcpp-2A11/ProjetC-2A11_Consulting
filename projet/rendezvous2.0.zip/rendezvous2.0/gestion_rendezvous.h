#ifndef GESTION_RENDEZVOUS_H
#define GESTION_RENDEZVOUS_H

#include <QMainWindow>
#include <QTableView>
#include <QSortFilterProxyModel>
#include "rendezvous.h"
#include "ui_gestion_rendezvous.h"

QT_BEGIN_NAMESPACE
namespace Ui {
class gestion_rendezvous;
}
QT_END_NAMESPACE

class gestion_rendezvous : public QMainWindow
{
    Q_OBJECT

public:
    gestion_rendezvous(QWidget *parent = nullptr);
    ~gestion_rendezvous();

    void notifierRendezVous();
    void envoyerSMS(const QString &numero, const QString &message);

private slots:
    void chargerclient();
    void afficherRendezVous();
    void on_ajouterButton_clicked();
    void on_supprimerButton_clicked();
    void on_modifierButton_clicked();
    void chargerRendezVousParID(const QString& id);
    void on_exportPdfButton_clicked();
    void chercherRendezVous();
    void on_filtrer_clicked();
    void on_bsms_clicked();




private:
    void afficherCalendrierRendezVous();
    Ui::gestion_rendezvous *ui;
    QSortFilterProxyModel *proxyModel;

    RendezVous rendezVous;
};

#endif // GESTION_RENDEZVOUS_H

