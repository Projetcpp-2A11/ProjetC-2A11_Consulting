#include "gestion_rendezvous.h"    // correspond à MainWindow
#include <QMessageBox>
#include <QApplication>
#include <QLocale>
#include <QTranslator>
#include "connection.h"            // classe pour gérer la connexion

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);

    // Connexion à la base de données
    Connection c;
    bool test = c.createconnection();

    // Traduction (optionnel)
    QTranslator translator;
    const QStringList uiLanguages = QLocale::system().uiLanguages();
    for (const QString &locale : uiLanguages) {
        const QString baseName = "Gcommande_" + QLocale(locale).name();
        if (translator.load(":/i18n/" + baseName)) {
            a.installTranslator(&translator);
            break;
        }
    }

    // Créer la fenêtre principale
    gestion_rendezvous w;

    // Message selon l'état de la connexion
    if (test) {
        QMessageBox::information(nullptr, QObject::tr("Base de données ouverte"),
                                 QObject::tr("Connexion réussie.\nCliquez sur OK pour continuer."),
                                 QMessageBox::Ok);
    } else {
        QMessageBox::critical(nullptr, QObject::tr("Base de données non ouverte"),
                              QObject::tr("Échec de la connexion.\nCertaines fonctionnalités seront désactivées."),
                              QMessageBox::Ok);
        // (Optionnel) désactiver des boutons ici si besoin via w.ui->xxx->setEnabled(false);
    }

    w.show();
    return a.exec();
}

